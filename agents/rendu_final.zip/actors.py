import gymnasium as gym
from bbrl.agents import Agent
import torch
import numpy as np
from gymnasium import spaces

class MyWrapper(gym.ActionWrapper):
    def __init__(self, env):
        super().__init__(env)

    def observation(self, obs):
        return 



class Actor(Agent):
    """Computes probabilities over action"""

    def forward(self, t: int):
        # Computes probabilities over actions
        pass


class ArgmaxActor(Agent):
    """Actor that computes the action"""

    def forward(self, t: int):
        # Selects the best actions according to the policy
        pass


class SamplingActor(Agent):
    """Samples random actions"""

    def __init__(self, action_space: gym.Space):
        super().__init__()
        self.action_space = action_space

    def forward(self, t: int):
        self.set(("action/steer", t), torch.tensor(3).unsqueeze(0))
        self.set(("action/acceleration", t), torch.tensor(2).unsqueeze(0))

class TrainedActor(Agent):
    """Actor that uses a trained model to select actions"""

    def __init__(self, model: torch.nn.Module):
        super().__init__()
        self.model = model

    def forward(self, t: int):
        X_max_steer_angle = self.get(("env/env_obs/max_steer_angle", t))
        X_velocity = self.get(("env/env_obs/velocity", t))
        X_center_path_distance = self.get(("env/env_obs/center_path_distance", t))
        X_center_path = self.get(("env/env_obs/center_path", t))
        X_front = self.get(("env/env_obs/front", t))
        X_paths_start = self.get(("env/env_obs/paths_start", t)).permute(1, 0, 2)[0]
        X_paths_end = self.get(("env/env_obs/paths_end", t)).permute(1, 0, 2)[0]
        X_paths_width = self.get(("env/env_obs/paths_width", t)).permute(1, 0, 2)[0]
        with torch.no_grad():
            action_continous = self.model(X_max_steer_angle, X_velocity, X_center_path_distance, X_center_path, X_front, X_paths_start, X_paths_end, X_paths_width)
        
        self.set(("action", t), action_continous)


class PPO_actor(Agent):
    """Actor that uses a trained model to select actions"""

    def __init__(self, model: torch.nn.Module):
        super().__init__()
        self.model = model

    def forward(self, t: int):
        X_velocity = self.get(("env/env_obs/velocity", t))
        X_center_path_distance = self.get(("env/env_obs/center_path_distance", t))
        X_center_path = self.get(("env/env_obs/center_path", t))
        X_front = self.get(("env/env_obs/front", t))
        X_paths_start = self.get(("env/env_obs/paths_start", t)).permute(1, 0, 2)[0]
        X_paths_end = self.get(("env/env_obs/paths_end", t)).permute(1, 0, 2)[0]
        observation = torch.cat([X_velocity, X_center_path_distance, X_center_path, X_front, X_paths_start, X_paths_end], dim=-1)

        scores = self.model(observation)
        action = scores.argmax(1)

        self.set(("action/acceleration", t), torch.tensor(4).unsqueeze(0))
        self.set(("action/steer", t), action)
