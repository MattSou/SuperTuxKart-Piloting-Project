from typing import List, Callable
from bbrl.agents import Agents, Agent
import gymnasium as gym
import torch
from torch import nn
import torch.nn.functional as F
import os
from pystk2_gymnasium.stk_wrappers import PolarObservations, ConstantSizedObservations, OnlyContinuousActionsWrapper, DiscreteActionsWrapper
from pystk2_gymnasium.wrappers import FlattenerWrapper, FlattenMultiDiscreteActions
from bbrl_utils.nn import build_mlp, setup_optimizer, soft_update_params, build_ortho_mlp, copy_parameters

# Imports our Actor class
# IMPORTANT: note the relative import
from .actors import Actor, MyWrapper, ArgmaxActor, SamplingActor, TrainedActor, PPO_actor

#: The base environment name
env_name = "supertuxkart/full-v0"

#: Player name
player_name = "Gitlab"

class Net(nn.Module):
    def __init__(self, size_max_steer_angle, size_velocity, size_center_path_distance, size_center_path, size_front, size_paths_start, size_paths_end, size_paths_width):
        super(Net, self).__init__()
        self.fc1 = nn.Linear(size_max_steer_angle + size_velocity + size_center_path_distance + size_center_path + size_front + size_paths_start + size_paths_end + size_paths_width, 256)
        self.fc2 = nn.Linear(256, 256)
        self.fc3 = nn.Linear(256, 256)
        self.fc5 = nn.Linear(256, 1)

        self.fc10 = nn.Linear(256, 1)

    def forward(self, x_max_steer_angle, x_velocity, x_center_path_distance, x_center_path, x_front, x_paths_start, x_paths_end, x_paths_width):
        x = torch.cat((x_max_steer_angle, x_velocity, x_center_path_distance, x_center_path, x_front, x_paths_start, x_paths_end, x_paths_width), dim=1)

        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = F.relu(self.fc3(x))
        z = self.fc5(x)
        z = torch.sigmoid(z)

        y = self.fc10(x)
        y = torch.tanh(y)
        return torch.cat((z, y), dim=1)
    
class Net_specifique(nn.Module):
    def __init__(self, size_max_steer_angle, size_velocity, size_center_path_distance, size_center_path, size_front, size_paths_start, size_paths_end, size_paths_width):
        super(Net_specifique, self).__init__()
        self.fc_velocity = nn.Linear(size_velocity, 32)
        self.fc_center_path_distance = nn.Linear(size_center_path_distance, 32)
        self.fc_center_path = nn.Linear(size_center_path, 32)
        self.fc_front = nn.Linear(size_front, 32)
        self.fc_paths_start = nn.Linear(size_paths_start, 32)
        self.fc_paths_end = nn.Linear(size_paths_end, 32)
        self.fc1 = nn.Linear(32*6, 256)
        self.fc2 = nn.Linear(256, 256)
        self.fc3 = nn.Linear(256, 256)
        self.fc4 = nn.Linear(256, 256)
        self.fc6 = nn.Linear(256, 256)

        self.fc5 = nn.Linear(256, 1)


        self.fc10 = nn.Linear(256, 1)

    def forward(self, x_max_steer_angle, x_velocity, x_center_path_distance, x_center_path, x_front, x_paths_start, x_paths_end, x_paths_width):
        x_velocity = F.relu(self.fc_velocity(x_velocity))
        x_center_path_distance = F.relu(self.fc_center_path_distance(x_center_path_distance))
        x_center_path = F.relu(self.fc_center_path(x_center_path))
        x_front = F.relu(self.fc_front(x_front))
        x_paths_start = F.relu(self.fc_paths_start(x_paths_start))
        x_paths_end = F.relu(self.fc_paths_end(x_paths_end))

        x = torch.cat((x_velocity, x_center_path_distance, x_center_path, x_front, x_paths_start, x_paths_end), dim=1)

        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = F.relu(self.fc3(x))
        x = F.relu(self.fc4(x))
        x = F.relu(self.fc6(x))
        z = self.fc5(x)
        z = torch.sigmoid(z)

        y = self.fc10(x)
        y = torch.tanh(y)
        return torch.cat((z, y), dim=1)

    
def get_actor(
    state, observation_space: gym.spaces.Space, action_space: gym.spaces.Space
) -> Agent:
    actor = Actor(observation_space, action_space)
    
    #model = Net_specifique(1,3,1,3,3,3,3,1)
    #affichage des fichiers
    #model.load_state_dict(torch.load('crab_model.pth'))
    model = build_ortho_mlp(
            [16] + list([512,512,512]) + [7], activation=nn.ReLU()
        )
    
    model.load_state_dict(state)

    return PPO_actor(model)

    return TrainedActor(model)
    # Returns a dummy actor
    if state is None:
        return SamplingActor(action_space)

    actor.load_state_dict(state)
    return Agents(actor, ArgmaxActor())


def get_wrappers() -> List[Callable[[gym.Env], gym.Wrapper]]:
    """Returns a list of additional wrappers to be applied to the base
    environment"""
    return [
        # Example of a custom wrapper
        lambda env: PolarObservations(ConstantSizedObservations(env)),
        lambda env: OnlyContinuousActionsWrapper(env),
        lambda env: DiscreteActionsWrapper(env)
        #lambda env: MyWrapper(env),
    ]
