import collections.abc
import gymnasium as gym
from bbrl.agents import Agent
import torch
import collections
from gymnasium.spaces.dict import Dict
from torch import nn
import numpy as np

class MyWrapper(gym.ActionWrapper):
    def __init__(self, env, option: int):
        super().__init__(env)
        self.option = option

    def action(self, action):
        # We do nothing here
        return action


class Actor(Agent):
    """Computes probabilities over action"""

    def forward(self, t: int):
        # Computes probabilities over actions
        pass


class ArgmaxActor(Agent):
    """Actor that computes the action"""

    def forward(self, t: int):
        probs = self.get(("action_probs", t))
        action = torch.argmax(probs, dim=1)
        self.set(("action", t), action)


class SamplingActor(Agent):
    """Samples random actions"""

    def __init__(self, action_space: gym.Space):
        super().__init__()
        self.action_space = action_space
        # print('value', self.action_space.sample())

    def forward(self, t: int):
        # print('value', torch.LongTensor([self.action_space.sample()]))
        if isinstance(self.action_space, Dict):
            value = {k: v.sample() for k, v in self.action_space.items()}
            for k, v in value.items():
                # print('v', v)
                value[k] = torch.FloatTensor(v) if v.dtype == 'float32' else torch.LongTensor(v)
                self.set((f"action/{k}", t), value[k])
        else:
            v = self.action_space.sample()
            if isinstance(v, collections.abc.Iterable):
                value = torch.FloatTensor(v) if v.dtype == 'float32' else torch.LongTensor(v)
            else:
                value = torch.FloatTensor([v]) if v.dtype == 'float32' else torch.LongTensor([v])
            self.set(("action", t), value)
        # print('final_value',value)

class NaiveActor(Agent):

    """Naive actor that always returns the same action"""

    def __init__(self, action: int):
        super().__init__()
        self.action = action
    
    def forward(self, t: int):
        self.set(("action", t), torch.LongTensor([self.action]))
        
class StochasticActorAgent(Agent):
    """Sample an action according to $p(a_t|s_t)$"""

    def forward(self, t: int, **kwargs):
        probs = self.get(("action_probs", t))
        action = torch.distributions.Categorical(probs).sample()
        # print(action)
        self.set(("action", t), torch.LongTensor([action]))

    
class PolicyBasedActor(Agent):
    def __init__(self, policy_path: str, observation_space: gym.Space):
        super().__init__()
        self.policy = torch.load(policy_path).cpu()
        self.observation_space = observation_space
        self.nvec = [5, 2, 2, 2, 2, 2, 7]

    def forward(self, t: int):
        discrete_obs = self.get(("env/env_obs/discrete", t))
        continuous_obs = self.get(("env/env_obs/continuous", t))
        obs = torch.cat([discrete_obs, continuous_obs], dim=1)
        action_probs = self.policy(obs).squeeze()
        # print(action_probs)
        aug_nvec = [0] + self.nvec
        aug_nvec = np.cumsum(aug_nvec)
        # print(aug_nvec)
        action_probs = [torch.softmax(action_probs[aug_nvec[i]:aug_nvec[i+1]], dim=-1) for i in range(len(aug_nvec)-1)]
        action_probs = multi_discrete_distribution(action_probs, self.nvec)

        self.set(("action_probs", t), action_probs)

def multi_discrete_distribution(discrete_distribution, nvec):
    # Returns a distribution over the product of discrete spaces
    """
    discrete_distribution: list of torch.Tensor
    """
    # print(discrete_distribution)
    n = np.prod(nvec)
    distrib = torch.zeros(n)
    for i in range(n):
        idx = i
        action = []
        for j in range(len(nvec)):
            action.append(idx % nvec[j])
            idx = idx // nvec[j]
        distrib[i] = discrete_distribution[0][action[0]]
        for j in range(1, len(nvec)):
            distrib[i] *= discrete_distribution[j][action[j]]
    return distrib