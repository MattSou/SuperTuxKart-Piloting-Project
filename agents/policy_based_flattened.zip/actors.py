import collections.abc
import gymnasium as gym
from bbrl.agents import Agent
import torch
import collections
from gymnasium.spaces.dict import Dict
from torch import nn

class MyWrapper(gym.ActionWrapper):
    def __init__(self, env, option: int):
        super().__init__(env)
        self.option = option

    def action(self, action):
        # We do nothing here
        return action


class Actor(Agent):
    """Computes probabilities over action"""

    def forward(self, t: int):
        # Computes probabilities over actions
        pass


class ArgmaxActor(Agent):
    """Actor that computes the action"""

    def forward(self, t: int):
        # Selects the best actions according to the policy
        pass


class SamplingActor(Agent):
    """Samples random actions"""

    def __init__(self, action_space: gym.Space):
        super().__init__()
        self.action_space = action_space
        # print('value', self.action_space.sample())

    def forward(self, t: int):
        # print('value', torch.LongTensor([self.action_space.sample()]))
        if isinstance(self.action_space, Dict):
            value = {k: v.sample() for k, v in self.action_space.items()}
            for k, v in value.items():
                # print('v', v)
                value[k] = torch.FloatTensor(v) if v.dtype == 'float32' else torch.LongTensor(v)
                self.set((f"action/{k}", t), value[k])
        else:
            v = self.action_space.sample()
            if isinstance(v, collections.abc.Iterable):
                value = torch.FloatTensor(v) if v.dtype == 'float32' else torch.LongTensor(v)
            else:
                value = torch.FloatTensor([v]) if v.dtype == 'float32' else torch.LongTensor([v])
            self.set(("action", t), value)
        # print('final_value',value)

class NaiveActor(Agent):

    """Naive actor that always returns the same action"""

    def __init__(self, action: int):
        super().__init__()
        self.action = action
    
    def forward(self, t: int):
        self.set(("action", t), torch.LongTensor([self.action]))
        
class PolicyBasedActor(Agent):
    def __init__(self, policy_discrete_path: str, policy_continuous_path: str, observation_space: gym.Space):
        super().__init__()
        self.policy_discrete = torch.load(policy_discrete_path).cpu()
        self.policy_continuous = torch.load(policy_continuous_path).cpu()
        self.observation_space = observation_space

    def forward(self, t: int):
        discrete_obs = self.get(("env/env_obs/discrete", t))
        continuous_obs = self.get(("env/env_obs/continuous", t))
        obs = torch.cat([discrete_obs, continuous_obs], dim=1)
        discrete_action = self.policy_discrete(obs).squeeze(0).long()
        continuous_action = self.policy_continuous(obs).squeeze(0)
        self.set(("action/discrete", t), discrete_action)
        self.set(("action/continuous", t), continuous_action)

