from pathlib import Path
from pystk2_gymnasium import AgentSpec
from functools import partial
import torch
import inspect
from bbrl.agents.gymnasium import ParallelGymAgent, make_env
import gymnasium as gym
from bbrl.agents import Agents, TemporalAgent
from tqdm import tqdm

# Note the use of relative imports
from .pystk_actor import env_name, get_wrappers, player_name
from .utils import sample_trajectories
from .actors import DiscreteStochaticActor, CategoricalChoiceActor
from omegaconf import OmegaConf

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')   

params = {
    # Set to true to have an insight on the learned policy
    # (but slows down the evaluation a lot!)
    "state": './model_discrete_true.pth',
    "algorithm": {
        "n_epochs": 30,
        "n_traj": 8,
        "horizon": 100,
        "max_grad_norm": 0.5,
        "discount_factor":0.98,
        "epsilon": 0.02,
        "batch_size": 64,
        "architecture": {
            "actor_hidden_size": [300, 300, 300, 300],
        },
    },
    "gym_env": {
        "env_name": env_name,
    },
}
cfg = OmegaConf.create(params)

def parse_space(space):
            if isinstance(space, gym.spaces.dict.Dict):
                n=0
                for k, v in space.spaces.items():
                    n+=parse_space(v)
                return n
            else:
                if len(space.shape) > 0:
                    if len(space.shape) > 1:
                        # warnings.warn(
                        #     "Multi dimensional space, be careful, a tuple (shape) "
                        #     "is returned, maybe youd like to flatten or simplify it first"
                        # )
                        return space.shape
                    return space.shape[0]
                else:
                    return space.n

if __name__ == "__main__":
    # Setup the environment
    make_stkenv = partial(
        make_env,
        env_name,
        wrappers=get_wrappers(),
        render_mode=None,
        autoreset=True,
        agent=AgentSpec(use_ai=False, name=player_name),
    )

    env_agent = ParallelGymAgent(make_stkenv, 1)
    env = env_agent.envs[0]

    obs_size = parse_space(env.observation_space)
    act_size = parse_space(env.action_space)
    # print(env.observation_space)
    # print(env.action_space)

    # (2) Learn
    if cfg.state:
        policy = DiscreteStochaticActor(obs_size, cfg.algorithm.architecture.actor_hidden_size, act_size, state=cfg.state)
    else:
        policy = DiscreteStochaticActor(obs_size, cfg.algorithm.architecture.actor_hidden_size, act_size)

    actor = Agents(policy, CategoricalChoiceActor())

    train_agent = TemporalAgent(Agents(env_agent, actor))

    optimizer = torch.optim.Adam(policy.parameters(), lr=1e-2)
    previous_actions_probs = None

    for epoch in range(cfg.algorithm.n_epochs):
        optimizer.zero_grad()
        observations, actions, rewards, probs = sample_trajectories(train_agent, env, cfg.algorithm.n_traj, cfg.algorithm.horizon, cfg.algorithm.discount_factor)
        # print(probs.shape, rewards.shape)
        # print(probs[0, 0][actions[0,0]])
        # print(actions[0,0])
        actions = actions.to(device)
        print(device)
        print(actions)
        print(probs)
        if previous_actions_probs is not None:
            # print(previous_actions_probs.shape)
            print(f"Evolution of action probs :{(previous_actions_probs-probs).norm()}")
        previous_actions_probs = probs.clone()
        

        probs = torch.gather(probs, -1, actions.unsqueeze(-1)).squeeze(-1)
        # print(probs[0, 0])
        # print(probs)
        print(min(rewards))
        rewards = rewards.to(device)
        loss = -(torch.log(probs).sum(-1) * (1+rewards.exp()).log()).mean()
        # print(loss)
        loss.backward()
        optimizer.step()

        # print(f"Evolution of action probs :{(previous_actions_probs-probs).norm()}")

        print("Epoch", epoch, "Loss", loss.item())

    

    # (3) Save the actor sate
    mod_path = Path(inspect.getfile(get_wrappers)).parent
    torch.save(policy.state_dict(), mod_path / "pystk_actor.pth")
