import collections.abc
import gymnasium as gym
from bbrl.agents import Agent
import torch
import collections
from gymnasium.spaces.dict import Dict
from torch import nn
from torch.distributions import Normal
from bbrl_utils.nn import build_mlp
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')   

class MyWrapper(gym.ActionWrapper):
    def __init__(self, env, option: int):
        super().__init__(env)
        self.option = option

    def action(self, action):
        # We do nothing here
        return action


class Actor(Agent):
    """Computes probabilities over action"""

    def forward(self, t: int):
        # Computes probabilities over actions
        pass


class ArgmaxActor(Agent):
    """Actor that computes the action"""

    def forward(self, t: int):
        # Selects the best actions according to the policy
        pass


class SamplingActor(Agent):
    """Samples random actions"""

    def __init__(self, action_space: gym.Space):
        super().__init__()
        self.action_space = action_space
        # print('value', self.action_space.sample())

    def forward(self, t: int):
        # print('value', torch.LongTensor([self.action_space.sample()]))
        if isinstance(self.action_space, Dict):
            value = {k: v.sample() for k, v in self.action_space.items()}
            for k, v in value.items():
                # print('v', v)
                value[k] = torch.FloatTensor(v) if v.dtype == 'float32' else torch.LongTensor(v)
                self.set((f"action/{k}", t), value[k])
        else:
            v = self.action_space.sample()
            if isinstance(v, collections.abc.Iterable):
                value = torch.FloatTensor(v) if v.dtype == 'float32' else torch.LongTensor(v)
            else:
                value = torch.FloatTensor([v]) if v.dtype == 'float32' else torch.LongTensor([v])
            self.set(("action", t), value)
        # print('final_value',value)

class NaiveActor(Agent):

    """Naive actor that always returns the same action"""

    def __init__(self, action: int):
        super().__init__()
        self.action = action
    
    def forward(self, t: int):
        self.set(("action", t), torch.LongTensor([self.action]))


class DiscreteStochaticActor(Agent):
    def __init__(self, state_dim, hidden_layers, action_dim, state=None):
        super().__init__()
        layers = [state_dim] + list(hidden_layers) + [action_dim]
        self.model = build_mlp(
            layers, activation=nn.ReLU(), output_activation=nn.Tanh()
        ).to(device)
        if state is not None:
            print('loading state')
            if isinstance(state, str):
                self.model.load_state_dict(torch.load(state))
            else:
                self.model.load_state_dict(state, strict=False)

    def forward(self, t, **kwargs):
        continuous_obs = self.get(("env/env_obs/continuous", t))
        discrete_obs = self.get(("env/env_obs/discrete", t))
        obs = torch.cat([discrete_obs, continuous_obs], dim=1).to(device)
        action = self.model(obs)
        action_probs = torch.softmax(action, dim=-1).pow(3)
        action_probs = action_probs / action_probs.sum(-1, keepdim=True)
        self.set(("action_probs", t), action_probs)



class CategoricalChoiceActor(Agent):
    def __init__(self):
        super().__init__()
    
    def forward(self, t, **kwargs):
        action_probs = self.get(("action_probs", t))
        dist = torch.distributions.Categorical(action_probs)
        action = dist.sample()
        self.set(("action", t), action)

class AddGaussianNoise(Agent):
    def __init__(self, sigma):
        super().__init__()
        self.sigma = torch.tensor(sigma)

    def forward(self, t, **kwargs):
        act = self.get(("action", t))
        dist = Normal(act, self.sigma)
        action = dist.sample()
        self.set(("action", t), action)