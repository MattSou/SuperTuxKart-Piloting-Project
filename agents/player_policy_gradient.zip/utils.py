from typing import Optional, Tuple

import torch
import torch.nn as nn
from bbrl.agents import Agent, Agents, TemporalAgent
from bbrl_utils.algorithms import EpisodicAlgo, EpochBasedAlgo
from bbrl_utils.nn import build_mlp, setup_optimizer, soft_update_params
from pathlib import Path
from bbrl.workspace import Workspace
from gymnasium.wrappers.monitoring.video_recorder import VideoRecorder

from bbrl.visu.plot_policies import plot_policy
import copy
from bbrl_utils.notebook import setup_tensorboard
from omegaconf import OmegaConf
import os
from bbrl_utils.nn import copy_parameters
from bbrl.agents.gymnasium import ParallelGymAgent
from bbrl_utils.notebook import video_display
from functools import partial
import gymnasium as gym
import numpy as np
from tqdm import tqdm

def get_obs_and_actions_sizes(env):
        obs_space = env.get_observation_space()
        act_space = env.get_action_space()
        # print(type(obs_space))
        # print(type(act_space))
        def parse_space(space):
            if isinstance(space, gym.spaces.dict.Dict):
                n=0
                for k, v in space.spaces.items():
                    n+=parse_space(v)
                return n
            else:
                if len(space.shape) > 0:
                    if len(space.shape) > 1:
                        # warnings.warn(
                        #     "Multi dimensional space, be careful, a tuple (shape) "
                        #     "is returned, maybe youd like to flatten or simplify it first"
                        # )
                        return space.shape
                    return space.shape[0]
                else:
                    return space.n
        
        return parse_space(obs_space), parse_space(act_space)

def sample_trajectories(agent: Agent, env, n_trajectories: int, horizon: int, discount_factor: float) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Sample a batch of trajectories

    :param agent: The agent
    :param env: The environment
    :param n_trajectories: The number of trajectories
    :param horizon: The maximum number of steps
    :return: A tuple (observations, actions, rewards, probs) 
    """
    # The observations, actions and rewards
    observations = []
    actions = []
    probs = []
    rewards = []

    for i in tqdm(range(n_trajectories)):
        train_workspace = Workspace()
        traj_obs = []
        traj_actions = []
        traj_rewards = []
        traj_probs = []
        obs, _ = env.reset()
        done = False
        t = 0
        offset = 0.1
        while not done and t < horizon:
            # Computes the action
            agent(train_workspace, t=t, n_steps=1)
            action = train_workspace.get("action", t).squeeze(0).cpu().numpy()
            action_probs = train_workspace.get("action_probs", t).squeeze(0)
            if t==0 and i == 0:
                print(action)
                print(action_probs[action])
                print(action_probs.sort(descending=True))
                print(action_probs.argsort(descending=True))
                
            # Takes a step
            next_obs, reward, done, _, info = env.step(action)
            # Stores the transition
            traj_obs.append(obs)
            traj_actions.append(action)
            traj_rewards.append(reward)
            traj_probs.append(action_probs)
            obs = next_obs
            t += 1
        # offset = min(offset, min(traj_rewards))
        observations.append(traj_obs)
        actions.append(traj_actions)
        probs.append(torch.stack(traj_probs))
        rewards.append(torch.tensor(np.array(traj_rewards)*np.array([discount_factor**i for i in range(len(traj_rewards))])).sum())
        # print(rewards)

    # print(probs)
    probs = torch.stack(probs)
    # print(probs)

    return observations, torch.tensor(np.array(actions)), torch.tensor(rewards), probs

